package com.example.kmj.dto;

import lombok.Data;

@Data
public class ReportRequestDTO {
    private Long boardId;
    private String reason;
}
