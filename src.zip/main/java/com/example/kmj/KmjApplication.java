package com.example.kmj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KmjApplication {
    public static void main(String[] args) {
        SpringApplication.run(KmjApplication.class, args);
    }
}
